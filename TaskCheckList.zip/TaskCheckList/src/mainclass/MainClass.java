/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package MainClass;

/**
 *
 * @author Administrator
 */
import controller.TaskController;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import model.TaskManager;
import utils.FileDBHelper;
import view.MainUI;

public class MainClass {

    public static void main(String[] args) {
        // 1. Initialize project directory
        FileDBHelper.createDirectory();

        // 2. Initialize the Look and Feel (L&F)
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
            Logger.getLogger(MainClass.class.getName()).log(Level.SEVERE, "Error setting System Look and Feel", ex);
        }

        // 3. MVC: create the Model and load persisted data
        TaskManager taskManager = new TaskManager();
        taskManager.loadTasks();

        // 4. Create the Controller, injecting the Model
        TaskController controller = new TaskController(taskManager);

        // 5. Launch the View on the Event Dispatch Thread (EDT)
        java.awt.EventQueue.invokeLater(() -> {
            MainUI view = new MainUI(controller);
            controller.setView(view);
            // Save data when the user closes the app
            view.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                    taskManager.saveTasks();
                    System.exit(0);
                }
            });
            view.setVisible(true);
        });
    }
}
