/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package view;

/**
 *
 * @author Administrator
 */
import controller.TaskController;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import model.Task;

/**
 * Main window: add, update, delete and tick off tasks.
 * Tasks are always shown sorted with Merge Sort (see TaskController).
 */
public class MainUI extends javax.swing.JFrame {

    private static final String APP_TITLE = "Task Checklist System";

    /**
     * Creates new form MainUI
     */
    public MainUI(TaskController controller) {
        this.controller = controller;
        this.tableModel = new TaskTableModel();
        initComponents();
        setupListTable();
        setupRowsActionListener();
        populatePriorityComboBox();
        setUpDefaults();
        refreshTasks();
        setLocationRelativeTo(null);
    }

    // default display
    private void setUpDefaults() {
        this.jBtnAdd.setEnabled(true);
        this.jBtnUpdate.setEnabled(false);
        this.jBtnDelete.setEnabled(false);
        this.jTFTaskTitle.setText("");
        this.jTADescription.setText("");
        this.jTFDueDate.setText("");
        this.jComboBoxPriority.setSelectedItem("Medium");
        this.selectedTaskId = null;
        this.jTableTasks.clearSelection();
    }

    private void populatePriorityComboBox() {
        jComboBoxPriority.setModel(new DefaultComboBoxModel<>(new String[]{"Low", "Medium", "High"}));
        jComboBoxPriority.setSelectedItem("Medium");
    }

    // setup table model
    private void setupListTable() {
        jTableTasks.setModel(tableModel);
        jTableTasks.getTableHeader().setReorderingAllowed(false);
        jTableTasks.setAutoCreateColumnsFromModel(true);
        jTableTasks.createDefaultColumnsFromModel();
        setupTableColumnWidths();

        // tick / untick the checkbox column -> save through the controller
        tableModel.setDoneListener((taskId, done) -> {
            if (!controller.handleToggleDone(taskId, done)) {
                JOptionPane.showMessageDialog(this, "Error updating task", APP_TITLE, JOptionPane.ERROR_MESSAGE);
            }
        });

        // completed tasks are shown in gray
        DefaultTableCellRenderer doneRenderer = new DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                java.awt.Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    int modelRow = table.convertRowIndexToModel(row);
                    c.setForeground(tableModel.isDone(modelRow) ? java.awt.Color.GRAY : table.getForeground());
                }
                return c;
            }
        };
        jTableTasks.setDefaultRenderer(String.class, doneRenderer);
    }

    private void setupTableColumnWidths() {
        javax.swing.table.TableColumnModel columnModel = jTableTasks.getColumnModel();

        // Column 0: Done (checkbox, narrow)
        columnModel.getColumn(0).setPreferredWidth(50);
        columnModel.getColumn(0).setMaxWidth(50);
        columnModel.getColumn(0).setMinWidth(50);
        // Column 1: Task title
        columnModel.getColumn(1).setPreferredWidth(190);
        // Column 2: Description (widest)
        columnModel.getColumn(2).setPreferredWidth(260);
        // Column 3: Priority
        columnModel.getColumn(3).setPreferredWidth(70);
        columnModel.getColumn(3).setMaxWidth(80);
        // Column 4: Due date
        columnModel.getColumn(4).setPreferredWidth(90);
        columnModel.getColumn(4).setMaxWidth(100);
        // Column 5: Created
        columnModel.getColumn(5).setPreferredWidth(150);
        columnModel.getColumn(5).setMaxWidth(170);

        jTableTasks.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_LAST_COLUMN);
    }

    private void setupRowsActionListener() {
        jTableTasks.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = jTableTasks.getSelectedRow();
                if (selectedRow != -1) {
                    int modelRow = jTableTasks.convertRowIndexToModel(selectedRow);
                    Task selectedTask = controller.getTaskDetails(this.tableModel.getTaskId(modelRow));
                    if (selectedTask != null) {
                        displaySelectedTask(selectedTask);
                    }
                }
            }
        });
    }

    private void displaySelectedTask(Task task) {
        this.jTFTaskTitle.setText(task.getTitle());
        this.jTADescription.setText(task.getDescription());
        this.jTFDueDate.setText(task.getDueDate() == null ? "" : task.getDueDate().toString());
        this.jComboBoxPriority.setSelectedItem(task.getPriority());
        this.selectedTaskId = task.getTaskId();

        // set display for buttons
        this.jBtnAdd.setEnabled(false);
        this.jBtnUpdate.setEnabled(true);
        this.jBtnDelete.setEnabled(true);
    }

    /** Reads the due date field. Empty means no due date; otherwise yyyy-MM-dd. */
    private LocalDate parseDueDate() {
        String text = this.jTFDueDate.getText().trim();
        return text.isEmpty() ? null : LocalDate.parse(text);
    }

    private void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, APP_TITLE, JOptionPane.INFORMATION_MESSAGE);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, APP_TITLE, JOptionPane.ERROR_MESSAGE);
    }

    private void updateTableTitle() {
        String title = String.format("My Tasks (%d/%d done) - %s",
                controller.getDoneCount(), controller.getTotalCount(), controller.getSortDescription());
        jLayeredPane1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, title,
                javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));
    }

    // refresh tasks (called by the controller after every change)
    public void refreshTasks() {
        String savedSelectedId = this.selectedTaskId;

        // tasks arrive already sorted by Merge Sort
        this.tableModel.setTasks(controller.getAllTasks());
        updateTableTitle();

        if (savedSelectedId != null) {
            int newModelRow = -1;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (savedSelectedId.equals(tableModel.getTaskId(i))) {
                    newModelRow = i;
                    break;
                }
            }
            if (newModelRow != -1) {
                int newTableRow = jTableTasks.convertRowIndexToView(newModelRow);
                jTableTasks.setRowSelectionInterval(newTableRow, newTableRow);
            } else {
                this.selectedTaskId = null;
                setUpDefaults();
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableTasks = new javax.swing.JTable();
        jTFTaskTitle = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTADescription = new javax.swing.JTextArea();
        jTFDueDate = new javax.swing.JTextField();
        jComboBoxPriority = new javax.swing.JComboBox<>();
        jBtnAdd = new javax.swing.JButton();
        jBtnUpdate = new javax.swing.JButton();
        jBtnDelete = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuManage = new javax.swing.JMenu();
        jMenuItemClearDone = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Task Checklist System");

        jLayeredPane1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "My Tasks", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        jTableTasks.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(jTableTasks);

        jLayeredPane1.setLayer(jScrollPane2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane1Layout = new javax.swing.GroupLayout(jLayeredPane1);
        jLayeredPane1.setLayout(jLayeredPane1Layout);
        jLayeredPane1Layout.setHorizontalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2)
                .addContainerGap())
        );
        jLayeredPane1Layout.setVerticalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jLayeredPane1Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 336, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTFTaskTitle.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTFTaskTitle.setBorder(javax.swing.BorderFactory.createTitledBorder("Task Title"));

        jTADescription.setColumns(20);
        jTADescription.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTADescription.setRows(5);
        jTADescription.setBorder(javax.swing.BorderFactory.createTitledBorder("Task Description"));
        jScrollPane1.setViewportView(jTADescription);

        jTFDueDate.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTFDueDate.setText("");
        jTFDueDate.setBorder(javax.swing.BorderFactory.createTitledBorder("Due Date (yyyy-MM-dd, optional)"));

        jComboBoxPriority.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jComboBoxPriority.setBorder(javax.swing.BorderFactory.createTitledBorder("Priority"));

        jBtnAdd.setFont(new java.awt.Font("sansserif", 1, 14)); // NOI18N
        jBtnAdd.setText("Add");
        jBtnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnAddActionPerformed(evt);
            }
        });

        jBtnUpdate.setFont(new java.awt.Font("sansserif", 1, 14)); // NOI18N
        jBtnUpdate.setText("Update");
        jBtnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnUpdateActionPerformed(evt);
            }
        });

        jBtnDelete.setFont(new java.awt.Font("sansserif", 1, 14)); // NOI18N
        jBtnDelete.setText("Delete");
        jBtnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnDeleteActionPerformed(evt);
            }
        });

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenuManage.setText("Manage");

        jMenuItemClearDone.setText("Delete Completed");
        jMenuItemClearDone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemClearDoneActionPerformed(evt);
            }
        });
        jMenuManage.add(jMenuItemClearDone);

        jMenuBar1.add(jMenuManage);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jTFDueDate)
                                .addComponent(jComboBoxPriority, 0, 283, Short.MAX_VALUE))
                            .addComponent(jTFTaskTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 405, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jBtnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 2, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jBtnAdd, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jBtnDelete, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addComponent(jLayeredPane1))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addGap(47, 47, 47)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jTFTaskTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTFDueDate, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboBoxPriority, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jBtnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jBtnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jBtnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jLayeredPane1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void jMenuItemClearDoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemClearDoneActionPerformed
        int confirm = JOptionPane.showConfirmDialog(this, "Delete all completed tasks?", APP_TITLE,
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm == JOptionPane.YES_OPTION) {
            int removed = controller.handleDeleteCompleted();
            showInfo(removed + " completed task(s) deleted");
            setUpDefaults();
        }
    }//GEN-LAST:event_jMenuItemClearDoneActionPerformed

    private void jBtnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnAddActionPerformed
        LocalDate dueDate;
        try {
            dueDate = parseDueDate();
        } catch (DateTimeParseException ex) {
            showError("Invalid due date. Use yyyy-MM-dd (example: 2026-11-30) or leave it empty.");
            return;
        }
        boolean res = controller.handleAddTask(this.jTFTaskTitle.getText(), this.jTADescription.getText(),
                (String) this.jComboBoxPriority.getSelectedItem(), dueDate);
        if (res) {
            showInfo("New task added");
            setUpDefaults();
        } else {
            showError("Error adding task. Please enter a task title.");
        }
    }//GEN-LAST:event_jBtnAddActionPerformed

    private void jBtnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnUpdateActionPerformed
        LocalDate dueDate;
        try {
            dueDate = parseDueDate();
        } catch (DateTimeParseException ex) {
            showError("Invalid due date. Use yyyy-MM-dd (example: 2026-11-30) or leave it empty.");
            return;
        }
        boolean res = controller.handleUpdateTask(this.selectedTaskId, this.jTFTaskTitle.getText(),
                this.jTADescription.getText(), (String) this.jComboBoxPriority.getSelectedItem(), dueDate);
        if (res) {
            showInfo("Task updated");
            setUpDefaults();
        } else {
            showError("Error updating task. Please enter a task title.");
        }
    }//GEN-LAST:event_jBtnUpdateActionPerformed

    private void jBtnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnDeleteActionPerformed
        int confirm = JOptionPane.showConfirmDialog(this, "Delete this task?", APP_TITLE,
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        boolean res = controller.handleDeleteTask(this.selectedTaskId);
        if (res) {
            showInfo("Task deleted");
        } else {
            showError("Error deleting task");
        }
        setUpDefaults();
    }//GEN-LAST:event_jBtnDeleteActionPerformed

    private final TaskTableModel tableModel;
    private final TaskController controller;
    private String selectedTaskId;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBtnAdd;
    private javax.swing.JButton jBtnDelete;
    private javax.swing.JButton jBtnUpdate;
    private javax.swing.JComboBox<String> jComboBoxPriority;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItemClearDone;
    private javax.swing.JMenu jMenuManage;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTADescription;
    private javax.swing.JTextField jTFDueDate;
    private javax.swing.JTextField jTFTaskTitle;
    private javax.swing.JTable jTableTasks;
    // End of variables declaration//GEN-END:variables
}
