/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package controller;

/**
 *
 * @author Administrator
 */
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import model.Task;
import model.TaskManager;
import view.MainUI;

public class TaskController {

    private final TaskManager model;
    private MainUI view;

    public TaskController(TaskManager model) {
        this.model = model;
    }

    public void setView(MainUI view) {
        this.view = view;
    }

    /** Text shown in the table title so the user can see how the list is sorted. */
    public String getSortDescription() {
        return "Merge Sort: Pending > Priority > Due Date > Newest";
    }

    /** Adds a new task (createdAt is set automatically). */
    public boolean handleAddTask(String title, String desc, String priority, LocalDate dueDate) {
        if (title == null || title.trim().isEmpty() || priority == null) {
            return false;
        }
        Task task = new Task(title.trim(), desc == null ? "" : desc.trim(), priority, dueDate);
        model.addTask(task);
        if (model.saveTasks() == -1) {
            model.deleteTask(task.getTaskId()); // undo, keep memory and file consistent
            return false;
        }
        refreshView();
        return true;
    }

    public boolean handleUpdateTask(String id, String title, String desc, String priority, LocalDate dueDate) {
        if (id == null || title == null || title.trim().isEmpty() || priority == null) {
            return false;
        }
        Task task = model.findTask(id);
        if (task == null) {
            return false;
        }
        task.setTitle(title.trim());
        task.setDescription(desc == null ? "" : desc.trim());
        task.setPriority(priority);
        task.setDueDate(dueDate);
        if (model.saveTasks() == -1) {
            return false;
        }
        refreshView();
        return true;
    }

    /** Called when the checkbox in the table is ticked or unticked. */
    public boolean handleToggleDone(String id, boolean done) {
        Task task = model.findTask(id);
        if (task == null) {
            return false;
        }
        task.setCompleted(done);
        if (model.saveTasks() == -1) {
            return false;
        }
        refreshView();
        return true;
    }

    public boolean handleDeleteTask(String id) {
        Task task = model.deleteTask(id);
        if (task == null) {
            return false;
        }
        model.saveTasks();
        refreshView();
        return true;
    }

    /** @return how many completed tasks were removed */
    public int handleDeleteCompleted() {
        List<String> ids = new ArrayList<>();
        for (Task t : model.findAll().values()) {
            if (t.isCompleted()) ids.add(t.getTaskId());
        }
        for (String id : ids) {
            model.deleteTask(id);
        }
        if (!ids.isEmpty()) {
            model.saveTasks();
            refreshView();
        }
        return ids.size();
    }

    /** All tasks, sorted with Merge Sort using the checklist order below. */
    public List<Task> getAllTasks() {
        List<Task> list = new ArrayList<>(model.findAll().values());
        return mergeSort(list, CHECKLIST_ORDER);
    }

    /**
     * The one sort order used by the system:
     * 1) pending tasks before completed ones
     * 2) higher priority first
     * 3) earlier due date first (tasks with no due date go last)
     * 4) newest created first
     */
    private static final Comparator<Task> CHECKLIST_ORDER = (a, b) -> {
        if (a.isCompleted() != b.isCompleted()) {
            return a.isCompleted() ? 1 : -1;
        }
        if (a.getPriorityRank() != b.getPriorityRank()) {
            return b.getPriorityRank() - a.getPriorityRank();
        }
        if (a.getDueDate() != null && b.getDueDate() != null) {
            int d = a.getDueDate().compareTo(b.getDueDate());
            if (d != 0) return d;
        } else if (a.getDueDate() != null) {
            return -1;
        } else if (b.getDueDate() != null) {
            return 1;
        }
        return b.getCreatedAt().compareTo(a.getCreatedAt());
    };

    
    private List<Task> mergeSort(List<Task> list, Comparator<Task> cmp) {
        if (list.size() <= 1) {
            return list;
        }
        int mid = list.size() / 2;
        List<Task> left = mergeSort(new ArrayList<>(list.subList(0, mid)), cmp);
        List<Task> right = mergeSort(new ArrayList<>(list.subList(mid, list.size())), cmp);
        return merge(left, right, cmp);
    }

    private List<Task> merge(List<Task> left, List<Task> right, Comparator<Task> cmp) {
        List<Task> result = new ArrayList<>(left.size() + right.size());
        int i = 0, j = 0;
        while (i < left.size() && j < right.size()) {
            // <= 0 takes from the left on ties, which is what keeps the sort stable
            if (cmp.compare(left.get(i), right.get(j)) <= 0) {
                result.add(left.get(i++));
            } else {
                result.add(right.get(j++));
            }
        }
        while (i < left.size()) result.add(left.get(i++));
        while (j < right.size()) result.add(right.get(j++));
        return result;
    }

    public Task getTaskDetails(String id) {
        return model.findTask(id);
    }

    public int getTotalCount() {
        return model.findAll().size();
    }

    public int getDoneCount() {
        int n = 0;
        for (Task t : model.findAll().values()) {
            if (t.isCompleted()) n++;
        }
        return n;
    }

    private void refreshView() {
        if (this.view != null) {
            this.view.refreshTasks();
        }
    }
}
